const _0x5e31ba = _0x46d1;

function _0x4d8b() {
    const _0x3b3e05 = ['argv', 'child', '20.0.04', 'Contoh : 628xxxxx', '2ySOsbw', 'stdin', 'includes', '99usgGhJ', 'requestPairingCode', 'user', 'black', '--mobile', 'messages', '└──────────────┈', '@whiskeysockets/baileys', 'join', 'catch', 'listMessage', 'question', 'matchAll', 'creds.update', '6282279915237', 'greenBright', 'templateMessage', 'fatal', 'util', 'replace', 'chalk', 'Silakan Tulis Nomor Whatsapp Anda', 'startsWith', 'pino', 'close', '280840FEUbyG', '386893dNltYK', 'messages.upsert', 'Connected ', 'exit', './lib/color', '--pairing-code', '161HTIitB', '20724cOCcHA', 'unwatchFile', 'buttonsMessage', 'resolve', 'decodeJid', '360896vSBKuf', '204xjdCad', 'match', 'authState', 'some', 'cache', 'watchFile', 'store', 'connection', './lib/myfunc', '80KomlKa', 'open', 'bgBlack', '130276piWeUB', 'message', 'server', 'Start with country code of your WhatsApp Number, Example : 628xxxxxxxx', 'Ubuntu', '2638785zxsDCU', 'log', 'loadMessage', 'white', '797731GityLV', 'registered', 'creds', '18bydclk', 'Connection Update :', 'keys', 'cyan', './session', 'redBright', 'readline', 'Your WhatsApp Number : ', '@s.whatsapp.net', 'default', 'stdout', '┌──────────────┈', 'sendMessage', './index', '│• ', './config', 'silent', 'bind'];
    _0x4d8b = function () {
        return _0x3b3e05;
    };
    return _0x4d8b();
}(function (_0xf5c3ff, _0x3987c9) {
    const _0x4d0ec9 = _0x46d1,
        _0x9b08b0 = _0xf5c3ff();
    while (!![]) {
        try {
            const _0x2cbd6c = -parseInt(_0x4d0ec9(0x18d)) / 0x1 * (parseInt(_0x4d0ec9(0x1c3)) / 0x2) + parseInt(_0x4d0ec9(0x1cf)) / 0x3 * (parseInt(_0x4d0ec9(0x1a9)) / 0x4) + parseInt(_0x4d0ec9(0x1c8)) / 0x5 + parseInt(_0x4d0ec9(0x1b1)) / 0x6 * (-parseInt(_0x4d0ec9(0x1b0)) / 0x7) + parseInt(_0x4d0ec9(0x1b6)) / 0x8 * (-parseInt(_0x4d0ec9(0x190)) / 0x9) + -parseInt(_0x4d0ec9(0x1c0)) / 0xa * (-parseInt(_0x4d0ec9(0x1cc)) / 0xb) + -parseInt(_0x4d0ec9(0x1b7)) / 0xc * (parseInt(_0x4d0ec9(0x1aa)) / 0xd);
            if (_0x2cbd6c === _0x3987c9) break;
            else _0x9b08b0['push'](_0x9b08b0['shift']());
        } catch (_0x3b9e1e) {
            _0x9b08b0['push'](_0x9b08b0['shift']());
        }
    }
}(_0x4d8b, 0x4d772), require(_0x5e31ba(0x186)));

function _0x46d1(_0x448da7, _0x18600e) {
    const _0x4d8bb8 = _0x4d8b();
    return _0x46d1 = function (_0x46d11c, _0x168090) {
        _0x46d11c = _0x46d11c - 0x179;
        let _0x4492c1 = _0x4d8bb8[_0x46d11c];
        return _0x4492c1;
    }, _0x46d1(_0x448da7, _0x18600e);
}
const {
    default: LexxyBotConnect,
    delay,
    jidNormalizedUser,
    PHONENUMBER_MCC,
    makeCacheableSignalKeyStore,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    getContentType,
    generateForwardMessageContent,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    generateMessageID,
    downloadContentFromMessage,
    makeInMemoryStore,
    jidDecode,
    proto
} = require(_0x5e31ba(0x197)), fs = require('fs'), pino = require(_0x5e31ba(0x1a7)), {
    join
} = require('path'), {
    await,
    getBuffer,
    fetchJson
} = require(_0x5e31ba(0x1bf)), makeWASocket = require(_0x5e31ba(0x197))[_0x5e31ba(0x180)], readline = require(_0x5e31ba(0x17d)), NodeCache = require('node-cache'), chalk = require(_0x5e31ba(0x1a4)), util = require(_0x5e31ba(0x1a2)), {
    color,
    mylog
} = require(_0x5e31ba(0x1ae)), store = makeInMemoryStore({
    'logger': pino()[_0x5e31ba(0x18a)]({
        'level': 'silent',
        'stream': _0x5e31ba(0x1bd)
    })
});
let phoneNumber = _0x5e31ba(0x19e);
const pairingCode = !!phoneNumber || process[_0x5e31ba(0x189)][_0x5e31ba(0x18f)](_0x5e31ba(0x1af)),
    useMobile = process['argv'][_0x5e31ba(0x18f)](_0x5e31ba(0x194)),
    xlec = readline['createInterface']({
        'input': process[_0x5e31ba(0x18e)],
        'output': process[_0x5e31ba(0x181)]
    }),
    question = _0x5d8871 => new Promise(_0x35b924 => xlec[_0x5e31ba(0x19b)](_0x5d8871, _0x35b924));
async function connectToWhatsApp() {
    const _0x2e5a9c = _0x5e31ba;
    let {
        version: _0x52765e,
        isLatest: _0x4c2be4
    } = await fetchLatestBaileysVersion();
    const {
        state: _0x3b24e5,
        saveCreds: _0x1e6251
    } = await useMultiFileAuthState(join(__dirname, _0x2e5a9c(0x17b))), _0x342595 = new NodeCache(), _0x5d3602 = makeWASocket({
        'logger': pino({
            'level': _0x2e5a9c(0x187)
        }),
        'printQRInTerminal': !pairingCode,
        'mobile': useMobile,
        'auth': {
            'creds': _0x3b24e5[_0x2e5a9c(0x1ce)],
            'keys': makeCacheableSignalKeyStore(_0x3b24e5[_0x2e5a9c(0x179)], pino({
                'level': 'fatal'
            })[_0x2e5a9c(0x18a)]({
                'level': _0x2e5a9c(0x1a1)
            }))
        },
        'browser': [_0x2e5a9c(0x1c7), 'Chrome', _0x2e5a9c(0x18b)],
        'version': _0x52765e,
        'patchMessageBeforeSending': _0x2c9c04 => {
            const _0x59cfe8 = _0x2e5a9c,
                _0x35fe4c = !!(_0x2c9c04[_0x59cfe8(0x1b3)] || _0x2c9c04[_0x59cfe8(0x1a0)] || _0x2c9c04[_0x59cfe8(0x19a)]);
            return _0x35fe4c && (_0x2c9c04 = {
                'viewOnceMessage': {
                    'message': {
                        'messageContextInfo': {
                            'deviceListMetadataVersion': 0x2,
                            'deviceListMetadata': {}
                        },
                        ..._0x2c9c04
                    }
                }
            }), _0x2c9c04;
        },
        'getMessage': async _0xc11c76 => {
            const _0x5b0c51 = _0x2e5a9c;
            let _0x582fb6 = jidNormalizedUser(_0xc11c76['remoteJid']),
                _0x4bfec3 = await store[_0x5b0c51(0x1ca)](_0x582fb6, _0xc11c76['id']);
            return _0x4bfec3?. [_0x5b0c51(0x1c4)] || '';
        },
        'markOnlineOnConnect': !![],
        'generateHighQualityLinkPreview': !![],
        'msgRetryCounterCache': _0x342595
    });
    store[_0x2e5a9c(0x188)](_0x5d3602['ev']);
    if (pairingCode && !_0x5d3602[_0x2e5a9c(0x1b9)][_0x2e5a9c(0x1ce)][_0x2e5a9c(0x1cd)]) {
        if (useMobile) console[_0x2e5a9c(0x1c9)]('Cannot use pairing code with mobile api');
        console[_0x2e5a9c(0x1c9)](chalk[_0x2e5a9c(0x17a)](_0x2e5a9c(0x182))), console[_0x2e5a9c(0x1c9)](_0x2e5a9c(0x185) + chalk[_0x2e5a9c(0x17c)](_0x2e5a9c(0x1a5))), console['log'](_0x2e5a9c(0x185) + chalk[_0x2e5a9c(0x17c)](_0x2e5a9c(0x18c))), console[_0x2e5a9c(0x1c9)](chalk[_0x2e5a9c(0x17a)](_0x2e5a9c(0x196)));
        let _0x50a88e;
        !!_0x50a88e ? (_0x50a88e = _0x50a88e[_0x2e5a9c(0x1a3)](/[^0-9]/g, ''), !Object[_0x2e5a9c(0x179)](PHONENUMBER_MCC)[_0x2e5a9c(0x1ba)](_0x1d3bbe => _0x50a88e['startsWith'](_0x1d3bbe)) && (console[_0x2e5a9c(0x1c9)](chalk['bgBlack'](chalk['redBright'](_0x2e5a9c(0x1c6)))), process[_0x2e5a9c(0x1ad)](0x0))) : (_0x50a88e = await question(chalk[_0x2e5a9c(0x1c2)](chalk[_0x2e5a9c(0x19f)]('Your WhatsApp Number : '))), _0x50a88e = _0x50a88e['replace'](/[^0-9]/g, ''), !Object[_0x2e5a9c(0x179)](PHONENUMBER_MCC)['some'](_0x32786f => _0x50a88e[_0x2e5a9c(0x1a6)](_0x32786f)) && (console[_0x2e5a9c(0x1c9)](chalk[_0x2e5a9c(0x1c2)](chalk[_0x2e5a9c(0x17c)]('Start with country code of your WhatsApp Number, Example : 628xxxxxxxx'))), _0x50a88e = await question(chalk['bgBlack'](chalk[_0x2e5a9c(0x19f)](_0x2e5a9c(0x17e)))), _0x50a88e = _0x50a88e[_0x2e5a9c(0x1a3)](/[^0-9]/g, ''), xlec[_0x2e5a9c(0x1a8)]())), setTimeout(async () => {
            const _0x2e3cc6 = _0x2e5a9c;
            let _0xdcfc3c = await _0x5d3602[_0x2e3cc6(0x191)](_0x50a88e);
            _0xdcfc3c = _0xdcfc3c?. [_0x2e3cc6(0x1b8)](/.{1,4}/g)?. [_0x2e3cc6(0x198)]('-') || _0xdcfc3c, console[_0x2e3cc6(0x1c9)](chalk[_0x2e3cc6(0x1c2)](chalk[_0x2e3cc6(0x19f)]('Copy Pairing Code :')), chalk[_0x2e3cc6(0x193)](chalk[_0x2e3cc6(0x1cb)](_0xdcfc3c)));
        }, 0x7d0);
    }
    return _0x5d3602['ev']['on'](_0x2e5a9c(0x1ab), async _0x26dac0 => {
        const _0x4dca63 = _0x2e5a9c;
        try {
            msg = _0x26dac0[_0x4dca63(0x195)][0x0];
            if (!msg['message']) return;
            require(_0x4dca63(0x184))(_0x5d3602, msg, store);
        } catch (_0x515f11) {
            console['log'](_0x515f11);
        }
    }), _0x5d3602['ev']['on']('connection.update', _0x36c2c7 => {
        const _0x15e217 = _0x2e5a9c;
        console[_0x15e217(0x1c9)](_0x15e217(0x1d0), _0x36c2c7);
        if (_0x36c2c7['connection'] === _0x15e217(0x1c1)) console[_0x15e217(0x1c9)](mylog(_0x15e217(0x1ac) + _0x5d3602[_0x15e217(0x192)]['id']));
        else _0x36c2c7[_0x15e217(0x1be)] === _0x15e217(0x1a8) && (console[_0x15e217(0x1c9)](mylog('Disconnected!')), connectToWhatsApp());
    }), _0x5d3602['sendTextWithMentions'] = async (_0x3248f6, _0x32eb84, _0x5212db, _0x1298fc = {}) => _0x5d3602[_0x2e5a9c(0x183)](_0x3248f6, {
        'text': _0x32eb84,
        'contextInfo': {
            'mentionedJid': [..._0x32eb84[_0x2e5a9c(0x19c)](/@(\d{0,16})/g)]['map'](_0x3a22c9 => _0x3a22c9[0x1] + _0x2e5a9c(0x17f))
        },
        ..._0x1298fc
    }, {
        'quoted': _0x5212db
    }), _0x5d3602[_0x2e5a9c(0x1b5)] = _0x50679d => {
        const _0x3c990f = _0x2e5a9c;
        if (!_0x50679d) return _0x50679d;
        if (/:\d+@/gi ['test'](_0x50679d)) {
            let _0x3e1f2d = jidDecode(_0x50679d) || {};
            return _0x3e1f2d['user'] && _0x3e1f2d[_0x3c990f(0x1c5)] && _0x3e1f2d[_0x3c990f(0x192)] + '@' + _0x3e1f2d[_0x3c990f(0x1c5)] || _0x50679d;
        } else return _0x50679d;
    }, _0x5d3602['sendmentions'] = (_0x16b940, _0x16d53b, _0x134596 = [], _0xd746da) => {
        const _0x47f5ec = _0x2e5a9c;
        if (_0xd746da == null || _0xd746da == undefined || _0xd746da == ![]) {
            let _0xd4cf3 = _0x5d3602['sendMessage'](_0x16b940, {
                'text': _0x16d53b,
                'mentions': _0x134596
            }, {
                'quoted': msg
            });
            return _0xd4cf3;
        } else {
            let _0x3fa023 = _0x5d3602[_0x47f5ec(0x183)](_0x16b940, {
                'text': _0x16d53b,
                'mentions': _0x134596
            }, {
                'quoted': msg
            });
            return _0x3fa023;
        }
    }, _0x5d3602['ev']['on'](_0x2e5a9c(0x19d), _0x1e6251), _0x5d3602;
}
connectToWhatsApp()[_0x5e31ba(0x199)](_0x7ba00d => console[_0x5e31ba(0x1c9)](_0x7ba00d));
let file = require[_0x5e31ba(0x1b4)](__filename);
fs[_0x5e31ba(0x1bc)](file, () => {
    const _0x6eb98d = _0x5e31ba;
    fs[_0x6eb98d(0x1b2)](file), console[_0x6eb98d(0x1c9)](chalk[_0x6eb98d(0x17c)]('Update ' + __filename)), delete require[_0x6eb98d(0x1bb)][file], require(file);
});