const fs = require('fs')
const chalk = require('chalk')

// ganti info bot dibawah ini
global.botName = "zuranet"
global.ownerName = "zuradev"
global.ownerBot = "62895423489481"
global.ownerNumber = ["62895423489481"] 

global.Auto_Typing = true // auto typing
global.Auto_Recording = false // auto recording
global.Auto_ReadPesan = true // auto read messages

// Auto Downloader Tiktok
global.TiktokAutoDownload = true

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})